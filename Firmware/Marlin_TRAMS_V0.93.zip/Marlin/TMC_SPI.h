#ifndef TMC_SPI_H
#define TMC_SPI_H

#include "Marlin.h"

void InitSPI();
uint8_t ReadWriteSPI(uint8_t Data);
uint32_t SPIRead(uint8_t address, uint8_t csPin);
FORCE_INLINE void SPIWrite(uint8_t address, uint32_t instruction, uint8_t csPin)
{
	uint8_t DATA1, DATA2, DATA3, DATA0;

	DATA0 = 0;
	DATA1 = 0;
	DATA2 = 0;
	DATA3 = 0;

	DATA0 = instruction & 0xFF;
	DATA1 = (instruction & 0xFF00) >> 8;
	DATA2 = (instruction & 0xFF0000) >> 16;
	DATA3 = (instruction & 0xFF000000) >> 24;

	address = address | 0x80;

	PORTL &= ~(1 << csPin); //csPin Low

	SPDR=address;
	while(!(SPSR & 0x80));

	SPDR=DATA3;
	while(!(SPSR & 0x80));

	SPDR=DATA2;
	while(!(SPSR & 0x80));

	SPDR=DATA1;
	while(!(SPSR & 0x80));

	SPDR=DATA0;
	while(!(SPSR & 0x80));

	PORTL |= (1 << csPin);//csPin High
}
uint8_t SPIRead_Status_Bits(uint8_t csPin);

#endif //TMC_SPI_H
